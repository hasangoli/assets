const initialState = {
  posts: [
    {
      id: 0,
      title: "Post Number 00",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 1,
      title: "Post Number 01",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 2,
      title: "Post Number 02",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 3,
      title: "Post Number 03",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 4,
      title: "Post Number 04",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 5,
      title: "Post Number 05",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 6,
      title: "Post Number 06",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 7,
      title: "Post Number 07",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
    {
      id: 8,
      title: "Post Number 08",
      body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consectetur dolorum ex a sequi nemo odit non velit atque amet minus porro laudantium nobis, delectus ad assumenda ea dicta aperiam? Aperiam?",
    },
  ],
};

const rootReducer = (state = initialState, action) => {
  return state;
};

export default rootReducer;
