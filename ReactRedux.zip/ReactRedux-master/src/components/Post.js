// import axios from "axios";
// import { useState } from "react";
// import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router";

export default function Post() {
  const { post_id } = useParams();
  // const [post, setPost] = useState([]);

  // useEffect(() => {
  //   axios
  //     .get(`http://jsonplaceholder.typicode.com/posts/${post_id}`)
  //     .then(res => setPost(res.data));
  // }, [post_id]);

  const post = useSelector(state => state.posts[post_id]);

  return (
    <div className="container">
      {post ? (
        <div className="post">
          <h4 className="center">{post.title}</h4>
          <p>{post.body}</p>
        </div>
      ) : (
        <div className="center">Loading post...</div>
      )}
    </div>
  );
}
