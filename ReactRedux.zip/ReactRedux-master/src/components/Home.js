// import axios from "axios";
// import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Subtract from "../assets/images/Subtract.png";
import { useSelector } from "react-redux";

export default function Home() {
  // const [posts, setPosts] = useState([]);

  // useEffect(() => {
  //   axios
  //     .get("http://jsonplaceholder.typicode.com/posts?_limit=13")
  //     .then(res => setPosts(res.data));
  // }, []);

  const posts = useSelector(state => state.posts);

  return (
    <div className="container">
      <h4 className="center">Home</h4>
      {posts.length > 1 ? (
        posts?.map(post => (
          <div className="post card" key={post.id}>
            <img className="post-img" src={Subtract} alt="Subtract" />
            <div className="card-content">
              <Link to={`/${post.id}`}>
                <span className="card-title">{post.title}</span>
              </Link>
              <p>{post.body}</p>
            </div>
          </div>
        ))
      ) : (
        <div className="center">No posts yet</div>
      )}
    </div>
  );
}
