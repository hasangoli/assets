export default function About() {
  return (
    <div className="container">
      <h4 className="center">About</h4>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Praesentium,
        quidem vel? Iure hic sequi animi ea harum quas neque illum ut! Quam,
        officiis in pariatur aliquam explicabo quo. Assumenda, a!
      </p>
    </div>
  );
}
